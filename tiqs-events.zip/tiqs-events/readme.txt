=== Oldskoolbelgium Events ===
Contributors: (this should be a list of wordpress.org userid's)
Tags: oldskool, belgium, Oldskoolbelgium
Requires PHP: 7.4
License: GPLv2 or later
This Plugin is for Oldskoolbelgium Events.

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin is for Oldskoolbelgium upcomming events

There are shortcodes mentions below

* tiqs-events
* tiqs-events-upcomming
* tiqs-event-details